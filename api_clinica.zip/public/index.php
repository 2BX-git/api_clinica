<?php
require_once __DIR__ . '/../src/Database.php';
require_once __DIR__ . '/../src/Auth/JWT.php';
require_once __DIR__ . '/../src/Middleware/AuthMiddleware.php';

use Src\Database;
use Src\Auth\JWT;
use Src\Middleware\AuthMiddleware;

// Headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Requested-With, Content-Type, Accept, Origin, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

// Função auxiliar para respostas JSON
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

// Verifica autenticação
function checkAuth() {
    $headers = getallheaders();
    $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

    if (!$token) {
        jsonResponse(['error' => 'Token não fornecido'], 401);
    }

    $payload = JWT::validateToken($token);
    if (!$payload) {
        jsonResponse(['error' => 'Token inválido ou expirado'], 401);
    }

    return $payload;
}

// Verificar se é uma rota protegida
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

// Rotas públicas
if ($uri === '/api_clinica/public/login' && $method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['email']) || !isset($data['senha'])) {
        jsonResponse(['error' => 'Email e senha são obrigatórios'], 400);
    }

    $db = new Database();
    $email = $data['email'];
    $senha = $data['senha'];

    $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        $tokenData = [
            'id' => $usuario['id'],
            'nome' => $usuario['nome'],
            'email' => $usuario['email'],
            'tipo' => $usuario['tipo']
        ];
        
        $token = JWT::generateToken($tokenData);

        jsonResponse([
            'message' => 'Login realizado com sucesso',
            'usuario' => $tokenData,
            'token' => $token
        ]);
    }

    jsonResponse(['error' => 'Credenciais inválidas'], 401);
}

// Rotas protegidas
if ($uri !== '/api_clinica/public/login' && $uri !== '/api_clinica/public/usuarios' || $method !== 'POST') {
    $user = checkAuth();
}

// Função para conectar ao banco de dados
function getDB() {
    return new Database();
}

// Pegar o método HTTP e a URL
$method = $_SERVER['REQUEST_METHOD'];
$request = $_SERVER['REQUEST_URI'];

// Remover a base da URL
$base = '/api_clinica/public/';
$request = substr($request, strlen($base));

// Remover parâmetros GET da URL
$requestParts = explode('?', $request);
$request = $requestParts[0];

$parts = explode('/', trim($request, '/'));

// Debug
error_log("Method: " . $method);
error_log("Request: " . $request);
error_log("Parts: " . print_r($parts, true));
error_log("Count Parts: " . count($parts));

// Rotas
try {
    $db = getDB();

    // Buscar horários disponíveis
    if ($method === 'GET' && count($parts) === 5 && 
        $parts[0] === 'profissionais' && 
        $parts[2] === 'clinicas' && 
        $parts[4] === 'horarios-disponiveis') {
        
        $profissionalId = $parts[1];
        $clinicaId = $parts[3];
        $data = isset($_GET['data']) ? $_GET['data'] : date('Y-m-d');
        $procedimentoId = isset($_GET['procedimento_id']) ? $_GET['procedimento_id'] : null;

        // Validar a data
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
            jsonResponse(['error' => 'Data inválida. Use o formato YYYY-MM-DD'], 400);
        }

        // Não permitir datas passadas
        if (strtotime($data) < strtotime(date('Y-m-d'))) {
            jsonResponse(['error' => 'Não é possível buscar horários para datas passadas'], 400);
        }

        // Verificar se o profissional está vinculado à clínica
        $stmt = $db->prepare("SELECT pc.id 
                             FROM profissionais_clinicas pc
                             JOIN profissionais p ON p.id = pc.profissional_id
                             WHERE pc.profissional_id = ? AND pc.clinica_id = ?");
        $stmt->execute([$profissionalId, $clinicaId]);
        $vinculo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$vinculo) {
            jsonResponse(['error' => 'Profissional não está vinculado a esta clínica'], 404);
        }

        // Obter o dia da semana da data solicitada (0 = Domingo, 6 = Sábado)
        $diaSemana = date('w', strtotime($data));

        // Buscar horários de trabalho para o dia da semana
        $stmt = $db->prepare("SELECT hora_inicio, hora_fim 
                             FROM horarios_trabalho 
                             WHERE profissional_clinica_id = ? 
                             AND dia_semana = ?
                             ORDER BY hora_inicio");
        $stmt->execute([$vinculo['id'], $diaSemana]);
        $horariosTrabalho = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($horariosTrabalho)) {
            jsonResponse(['error' => 'Profissional não atende neste dia da semana'], 404);
        }

        // Buscar duração do procedimento
        $duracaoProcedimento = 30; // Duração padrão em minutos
        if ($procedimentoId) {
            $stmt = $db->prepare("SELECT duracao FROM procedimentos WHERE id = ?");
            $stmt->execute([$procedimentoId]);
            $procedimento = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($procedimento) {
                $duracaoProcedimento = $procedimento['duracao'];
            }
        }

        // Buscar agendamentos existentes para o dia
        $stmt = $db->prepare("SELECT hora_inicio, hora_fim 
                             FROM agendamentos 
                             WHERE profissional_id = ? 
                             AND clinica_id = ?
                             AND data_agendamento = ?
                             AND status != 'cancelado'
                             ORDER BY hora_inicio");
        $stmt->execute([$profissionalId, $clinicaId, $data]);
        $agendamentosExistentes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Gerar horários disponíveis
        $horariosDisponiveis = [];
        foreach ($horariosTrabalho as $horario) {
            $inicio = new DateTime($horario['hora_inicio']);
            $fim = new DateTime($horario['hora_fim']);
            
            // Gerar slots de acordo com a duração do procedimento
            while ($inicio->add(new DateInterval('PT' . $duracaoProcedimento . 'M')) <= $fim) {
                $inicio->sub(new DateInterval('PT' . $duracaoProcedimento . 'M'));
                $slotInicio = $inicio->format('H:i:s');
                $slotFim = $inicio->add(new DateInterval('PT' . $duracaoProcedimento . 'M'))->format('H:i:s');
                
                // Verificar se o horário não conflita com agendamentos existentes
                $disponivel = true;
                foreach ($agendamentosExistentes as $agendamento) {
                    if (($slotInicio >= $agendamento['hora_inicio'] && $slotInicio < $agendamento['hora_fim']) ||
                        ($slotFim > $agendamento['hora_inicio'] && $slotFim <= $agendamento['hora_fim']) ||
                        ($slotInicio <= $agendamento['hora_inicio'] && $slotFim >= $agendamento['hora_fim'])) {
                        $disponivel = false;
                        break;
                    }
                }

                // Se for hoje, não mostrar horários que já passaram
                if ($data === date('Y-m-d')) {
                    $horaAtual = new DateTime();
                    $horaSlot = new DateTime($data . ' ' . $slotInicio);
                    if ($horaSlot <= $horaAtual) {
                        $disponivel = false;
                    }
                }

                if ($disponivel) {
                    $horariosDisponiveis[] = [
                        'inicio' => $slotInicio,
                        'fim' => $slotFim
                    ];
                }
            }
        }

        jsonResponse([
            'data' => $data,
            'dia_semana' => $diaSemana,
            'duracao_procedimento' => $duracaoProcedimento,
            'horarios_disponiveis' => $horariosDisponiveis
        ]);
    }

    // Criar usuário
    if ($method === 'POST' && $request === 'usuarios') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['email']) || !isset($data['senha']) || !isset($data['tipo'])) {
            jsonResponse(['error' => 'Nome, email, senha e tipo são obrigatórios'], 400);
        }

        // Verificar se email já existe
        $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->execute([$data['email']]);
        if ($stmt->fetch()) {
            jsonResponse(['error' => 'Email já cadastrado'], 400);
        }

        // Hash da senha
        $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);

        $stmt = $db->prepare("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data['nome'], $data['email'], $senhaHash, $data['tipo']]);
        
        jsonResponse(['message' => 'Usuário criado com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Autenticação
    if ($method === 'POST' && $parts[0] === 'login') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['email']) || !isset($data['senha'])) {
            jsonResponse(['error' => 'Email e senha são obrigatórios'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = ?");
        $stmt->execute([$data['email']]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario || !password_verify($data['senha'], $usuario['senha'])) {
            jsonResponse(['error' => 'Credenciais inválidas'], 401);
        }

        $token = JWT::generateToken($usuario);
        jsonResponse([
            'message' => 'Login realizado com sucesso',
            'usuario' => [
                'id' => $usuario['id'],
                'nome' => $usuario['nome'],
                'email' => $usuario['email'],
                'tipo' => $usuario['tipo']
            ],
            'token' => $token
        ]);
    }

    // === ROTAS DE CLÍNICAS ===
    
    // Listar clínicas
    if ($method === 'GET' && $request === 'clinicas') {
        $stmt = $db->query("SELECT * FROM clinicas");
        $clinicas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse($clinicas);
    }

    // Criar clínica
    if ($method === 'POST' && $request === 'clinicas') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['endereco'])) {
            jsonResponse(['error' => 'Nome e endereço são obrigatórios'], 400);
        }

        $stmt = $db->prepare("INSERT INTO clinicas (nome, endereco, telefone) VALUES (?, ?, ?)");
        $stmt->execute([$data['nome'], $data['endereco'], $data['telefone'] ?? null]);
        
        jsonResponse(['message' => 'Clínica criada com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Obter clínica específica
    if ($method === 'GET' && $parts[0] === 'clinicas' && isset($parts[1]) && !isset($parts[2])) {
        $stmt = $db->prepare("SELECT * FROM clinicas WHERE id = ?");
        $stmt->execute([$parts[1]]);
        $clinica = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$clinica) {
            jsonResponse(['error' => 'Clínica não encontrada'], 404);
        }
        
        jsonResponse($clinica);
    }

    // Atualizar clínica
    if ($method === 'PUT' && $parts[0] === 'clinicas' && isset($parts[1])) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['endereco'])) {
            jsonResponse(['error' => 'Nome e endereço são obrigatórios'], 400);
        }

        $stmt = $db->prepare("UPDATE clinicas SET nome = ?, endereco = ?, telefone = ?, updated_at = NOW() WHERE id = ?");
        if ($stmt->execute([$data['nome'], $data['endereco'], $data['telefone'] ?? null, $parts[1]])) {
            jsonResponse(['message' => 'Clínica atualizada com sucesso']);
        }
        jsonResponse(['error' => 'Clínica não encontrada'], 404);
    }

    // Deletar clínica
    if ($method === 'DELETE' && $parts[0] === 'clinicas' && isset($parts[1])) {
        // Verificar se existem agendamentos futuros
        $stmt = $db->prepare("SELECT COUNT(*) FROM agendamentos WHERE clinica_id = ? AND data_agendamento >= CURDATE()");
        $stmt->execute([$parts[1]]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Não é possível excluir. Existem agendamentos futuros para esta clínica.'], 400);
        }

        $stmt = $db->prepare("DELETE FROM clinicas WHERE id = ?");
        if ($stmt->execute([$parts[1]])) {
            jsonResponse(['message' => 'Clínica excluída com sucesso']);
        }
        jsonResponse(['error' => 'Clínica não encontrada'], 404);
    }

    // === ROTAS DE PROFISSIONAIS ===

    // Listar profissionais
    if ($method === 'GET' && $request === 'profissionais') {
        $query = "SELECT p.*, u.nome, u.email, e.nome as especialidade 
                 FROM profissionais p
                 JOIN usuarios u ON u.id = p.usuario_id
                 JOIN especialidades e ON e.id = p.especialidade_id";
        $stmt = $db->query($query);
        $profissionais = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse($profissionais);
    }

    // Criar profissional
    if ($method === 'POST' && $request === 'profissionais') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['usuario_id']) || !isset($data['especialidade_id'])) {
            jsonResponse(['error' => 'Todos os campos obrigatórios devem ser preenchidos'], 400);
        }

        // Verificar se usuário existe e é do tipo profissional
        $stmt = $db->prepare("SELECT tipo FROM usuarios WHERE id = ?");
        $stmt->execute([$data['usuario_id']]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$usuario) {
            jsonResponse(['error' => 'Usuário não encontrado'], 404);
        }
        
        if ($usuario['tipo'] !== 'profissional') {
            jsonResponse(['error' => 'Usuário não é um profissional'], 400);
        }

        // Verificar se especialidade existe
        $stmt = $db->prepare("SELECT id FROM especialidades WHERE id = ?");
        $stmt->execute([$data['especialidade_id']]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Especialidade não encontrada'], 404);
        }

        // Criar profissional
        $stmt = $db->prepare("INSERT INTO profissionais (usuario_id, especialidade_id, registro_profissional) VALUES (?, ?, ?)");
        $stmt->execute([
            $data['usuario_id'],
            $data['especialidade_id'],
            $data['registro_profissional'] ?? null
        ]);

        jsonResponse(['message' => 'Profissional criado com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Obter profissional específico
    if ($method === 'GET' && $parts[0] === 'profissionais' && isset($parts[1]) && !isset($parts[2])) {
        $query = "SELECT p.*, u.nome, u.email, e.nome as especialidade 
                 FROM profissionais p
                 JOIN usuarios u ON u.id = p.usuario_id
                 JOIN especialidades e ON e.id = p.especialidade_id
                 WHERE p.id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$parts[1]]);
        $profissional = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$profissional) {
            jsonResponse(['error' => 'Profissional não encontrado'], 404);
        }
        
        jsonResponse($profissional);
    }

    // Atualizar profissional
    if ($method === 'PUT' && $parts[0] === 'profissionais' && isset($parts[1])) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['email']) || !isset($data['especialidade_id'])) {
            jsonResponse(['error' => 'Todos os campos obrigatórios devem ser preenchidos'], 400);
        }

        $db->beginTransaction();
        try {
            // Obter o ID do usuário do profissional
            $stmt = $db->prepare("SELECT usuario_id FROM profissionais WHERE id = ?");
            $stmt->execute([$parts[1]]);
            $profissional = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$profissional) {
                $db->rollBack();
                jsonResponse(['error' => 'Profissional não encontrado'], 404);
            }

            // Atualizar usuário
            $stmt = $db->prepare("UPDATE usuarios SET nome = ?, email = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$data['nome'], $data['email'], $profissional['usuario_id']]);

            // Atualizar profissional
            $stmt = $db->prepare("UPDATE profissionais SET especialidade_id = ?, registro_profissional = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$data['especialidade_id'], $data['registro_profissional'] ?? null, $parts[1]]);

            $db->commit();
            jsonResponse(['message' => 'Profissional atualizado com sucesso']);
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    // Deletar profissional
    if ($method === 'DELETE' && $parts[0] === 'profissionais' && isset($parts[1])) {
        // Verificar se existem agendamentos futuros
        $stmt = $db->prepare("SELECT COUNT(*) FROM agendamentos WHERE profissional_id = ? AND data_agendamento >= CURDATE()");
        $stmt->execute([$parts[1]]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Não é possível excluir. Existem agendamentos futuros para este profissional.'], 400);
        }

        $db->beginTransaction();
        try {
            // Obter o ID do usuário
            $stmt = $db->prepare("SELECT usuario_id FROM profissionais WHERE id = ?");
            $stmt->execute([$parts[1]]);
            $profissional = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$profissional) {
                $db->rollBack();
                jsonResponse(['error' => 'Profissional não encontrado'], 404);
            }

            // Deletar profissional
            $stmt = $db->prepare("DELETE FROM profissionais WHERE id = ?");
            $stmt->execute([$parts[1]]);

            // Deletar usuário
            $stmt = $db->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->execute([$profissional['usuario_id']]);

            $db->commit();
            jsonResponse(['message' => 'Profissional excluído com sucesso']);
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    // === ROTAS DE ESPECIALIDADES ===

    // Listar especialidades
    if ($method === 'GET' && $request === 'especialidades') {
        $stmt = $db->query("SELECT * FROM especialidades");
        $especialidades = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse($especialidades);
    }

    // Criar especialidade
    if ($method === 'POST' && $request === 'especialidades') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome'])) {
            jsonResponse(['error' => 'Nome é obrigatório'], 400);
        }

        $stmt = $db->prepare("INSERT INTO especialidades (nome, descricao) VALUES (?, ?)");
        $stmt->execute([$data['nome'], $data['descricao'] ?? null]);
        
        jsonResponse(['message' => 'Especialidade criada com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Obter especialidade específica
    if ($method === 'GET' && $parts[0] === 'especialidades' && isset($parts[1]) && !isset($parts[2])) {
        $stmt = $db->prepare("SELECT * FROM especialidades WHERE id = ?");
        $stmt->execute([$parts[1]]);
        $especialidade = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$especialidade) {
            jsonResponse(['error' => 'Especialidade não encontrada'], 404);
        }
        
        jsonResponse($especialidade);
    }

    // Atualizar especialidade
    if ($method === 'PUT' && $parts[0] === 'especialidades' && isset($parts[1])) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome'])) {
            jsonResponse(['error' => 'Nome é obrigatório'], 400);
        }

        $stmt = $db->prepare("UPDATE especialidades SET nome = ?, descricao = ?, updated_at = NOW() WHERE id = ?");
        if ($stmt->execute([$data['nome'], $data['descricao'] ?? null, $parts[1]])) {
            jsonResponse(['message' => 'Especialidade atualizada com sucesso']);
        }
        jsonResponse(['error' => 'Especialidade não encontrada'], 404);
    }

    // Deletar especialidade
    if ($method === 'DELETE' && $parts[0] === 'especialidades' && isset($parts[1])) {
        // Verificar se existem profissionais ou procedimentos vinculados
        $stmt = $db->prepare("SELECT COUNT(*) FROM profissionais WHERE especialidade_id = ?");
        $stmt->execute([$parts[1]]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Não é possível excluir. Existem profissionais vinculados a esta especialidade.'], 400);
        }

        $stmt = $db->prepare("SELECT COUNT(*) FROM procedimentos WHERE especialidade_id = ?");
        $stmt->execute([$parts[1]]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Não é possível excluir. Existem procedimentos vinculados a esta especialidade.'], 400);
        }

        $stmt = $db->prepare("DELETE FROM especialidades WHERE id = ?");
        if ($stmt->execute([$parts[1]])) {
            jsonResponse(['message' => 'Especialidade excluída com sucesso']);
        }
        jsonResponse(['error' => 'Especialidade não encontrada'], 404);
    }

    // === ROTAS DE PROCEDIMENTOS ===

    // Listar procedimentos
    if ($method === 'GET' && $request === 'procedimentos') {
        $query = "SELECT p.*, e.nome as especialidade
                 FROM procedimentos p
                 JOIN especialidades e ON e.id = p.especialidade_id";
        $stmt = $db->query($query);
        $procedimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse($procedimentos);
    }

    // Criar procedimento
    if ($method === 'POST' && $request === 'procedimentos') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['especialidade_id']) || !isset($data['duracao'])) {
            jsonResponse(['error' => 'Nome, especialidade e duração são obrigatórios'], 400);
        }

        $stmt = $db->prepare("INSERT INTO procedimentos (nome, descricao, duracao, especialidade_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $data['nome'],
            $data['descricao'] ?? null,
            $data['duracao'],
            $data['especialidade_id']
        ]);
        
        jsonResponse(['message' => 'Procedimento criado com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Obter procedimento específico
    if ($method === 'GET' && $parts[0] === 'procedimentos' && isset($parts[1]) && !isset($parts[2])) {
        $query = "SELECT p.*, e.nome as especialidade
                 FROM procedimentos p
                 JOIN especialidades e ON e.id = p.especialidade_id
                 WHERE p.id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$parts[1]]);
        $procedimento = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$procedimento) {
            jsonResponse(['error' => 'Procedimento não encontrado'], 404);
        }
        
        jsonResponse($procedimento);
    }

    // Atualizar procedimento
    if ($method === 'PUT' && $parts[0] === 'procedimentos' && isset($parts[1])) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['especialidade_id']) || !isset($data['duracao'])) {
            jsonResponse(['error' => 'Nome, especialidade e duração são obrigatórios'], 400);
        }

        $stmt = $db->prepare("UPDATE procedimentos SET nome = ?, descricao = ?, duracao = ?, especialidade_id = ?, updated_at = NOW() WHERE id = ?");
        if ($stmt->execute([
            $data['nome'],
            $data['descricao'] ?? null,
            $data['duracao'],
            $data['especialidade_id'],
            $parts[1]
        ])) {
            jsonResponse(['message' => 'Procedimento atualizado com sucesso']);
        }
        jsonResponse(['error' => 'Procedimento não encontrado'], 404);
    }

    // Deletar procedimento
    if ($method === 'DELETE' && $parts[0] === 'procedimentos' && isset($parts[1])) {
        // Verificar se existem agendamentos futuros
        $stmt = $db->prepare("SELECT COUNT(*) FROM agendamentos WHERE procedimento_id = ? AND data_agendamento >= CURDATE()");
        $stmt->execute([$parts[1]]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Não é possível excluir. Existem agendamentos futuros para este procedimento.'], 400);
        }

        $stmt = $db->prepare("DELETE FROM procedimentos WHERE id = ?");
        if ($stmt->execute([$parts[1]])) {
            jsonResponse(['message' => 'Procedimento excluído com sucesso']);
        }
        jsonResponse(['error' => 'Procedimento não encontrado'], 404);
    }

    // === ROTAS DE AGENDAMENTOS ===

    // Listar agendamentos
    if ($method === 'GET' && $request === 'agendamentos') {
        $query = "SELECT a.*, 
                        c.nome as clinica_nome,
                        u.nome as profissional_nome,
                        p.nome as procedimento_nome
                 FROM agendamentos a
                 JOIN clinicas c ON c.id = a.clinica_id
                 JOIN profissionais pr ON pr.id = a.profissional_id
                 JOIN usuarios u ON u.id = pr.usuario_id
                 JOIN procedimentos p ON p.id = a.procedimento_id
                 ORDER BY a.data_agendamento, a.hora_inicio";
        $stmt = $db->query($query);
        $agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse($agendamentos);
    }

    // Criar agendamento
    if ($method === 'POST' && $request === 'agendamentos') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validar campos obrigatórios
        $requiredFields = ['profissional_id', 'clinica_id', 'procedimento_id', 'data_agendamento', 
                          'hora_inicio', 'paciente_nome', 'paciente_telefone'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                jsonResponse(['error' => "Campo $field é obrigatório"], 400);
            }
        }

        // Validar vínculo profissional-clínica
        $stmt = $db->prepare("SELECT id FROM profissionais_clinicas WHERE profissional_id = ? AND clinica_id = ?");
        $stmt->execute([$data['profissional_id'], $data['clinica_id']]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Profissional não está vinculado a esta clínica'], 400);
        }

        // Validar procedimento
        $stmt = $db->prepare("SELECT duracao FROM procedimentos WHERE id = ?");
        $stmt->execute([$data['procedimento_id']]);
        $procedimento = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$procedimento) {
            jsonResponse(['error' => 'Procedimento não encontrado'], 404);
        }

        // Calcular hora fim
        $horaInicio = new DateTime($data['hora_inicio']);
        $horaFim = clone $horaInicio;
        $horaFim->add(new DateInterval('PT' . $procedimento['duracao'] . 'M'));

        // Verificar disponibilidade
        $stmt = $db->prepare("SELECT COUNT(*) FROM agendamentos 
                             WHERE profissional_id = ? AND clinica_id = ? 
                             AND data_agendamento = ? AND status != 'cancelado'
                             AND ((hora_inicio <= ? AND hora_fim > ?) 
                             OR (hora_inicio < ? AND hora_fim >= ?))");
        $stmt->execute([
            $data['profissional_id'],
            $data['clinica_id'],
            $data['data_agendamento'],
            $data['hora_inicio'],
            $data['hora_inicio'],
            $horaFim->format('H:i:s'),
            $horaFim->format('H:i:s')
        ]);
        
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Horário não disponível'], 400);
        }

        // Criar agendamento
        $stmt = $db->prepare("INSERT INTO agendamentos 
                             (profissional_id, clinica_id, procedimento_id, paciente_nome, 
                              paciente_telefone, data_agendamento, hora_inicio, hora_fim, 
                              status, observacoes, created_at, updated_at) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'agendado', ?, NOW(), NOW())");
        $stmt->execute([
            $data['profissional_id'],
            $data['clinica_id'],
            $data['procedimento_id'],
            $data['paciente_nome'],
            $data['paciente_telefone'],
            $data['data_agendamento'],
            $data['hora_inicio'],
            $horaFim->format('H:i:s'),
            $data['observacoes'] ?? null
        ]);

        jsonResponse(['message' => 'Agendamento criado com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Obter agendamento específico
    if ($method === 'GET' && $parts[0] === 'agendamentos' && isset($parts[1]) && !isset($parts[2])) {
        $query = "SELECT a.*, 
                        c.nome as clinica_nome,
                        u.nome as profissional_nome,
                        p.nome as procedimento_nome
                 FROM agendamentos a
                 JOIN clinicas c ON c.id = a.clinica_id
                 JOIN profissionais pr ON pr.id = a.profissional_id
                 JOIN usuarios u ON u.id = pr.usuario_id
                 JOIN procedimentos p ON p.id = a.procedimento_id
                 WHERE a.id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$parts[1]]);
        $agendamento = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$agendamento) {
            jsonResponse(['error' => 'Agendamento não encontrado'], 404);
        }
        
        jsonResponse($agendamento);
    }

    // Atualizar status do agendamento
    if ($method === 'PUT' && count($parts) === 2 && $parts[0] === 'agendamentos') {
        $agendamentoId = $parts[1];
        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['status'])) {
            jsonResponse(['error' => 'Status é obrigatório'], 400);
        }

        // Verificar se agendamento existe
        $stmt = $db->prepare("SELECT status FROM agendamentos WHERE id = ?");
        $stmt->execute([$agendamentoId]);
        $agendamento = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$agendamento) {
            jsonResponse(['error' => 'Agendamento não encontrado'], 404);
        }

        // Validar status
        $statusPermitidos = ['agendado', 'confirmado', 'cancelado', 'realizado'];
        if (!in_array($data['status'], $statusPermitidos)) {
            jsonResponse(['error' => 'Status inválido'], 400);
        }

        // Não permitir alteração de agendamentos já realizados
        if ($agendamento['status'] === 'realizado') {
            jsonResponse(['error' => 'Não é possível alterar um agendamento já realizado'], 400);
        }

        // Atualizar status
        $stmt = $db->prepare("UPDATE agendamentos SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$data['status'], $agendamentoId]);
        
        jsonResponse(['message' => 'Status do agendamento atualizado com sucesso']);
    }

    // === ROTAS DE VÍNCULOS PROFISSIONAL-CLÍNICA ===

    // Listar clínicas do profissional
    if ($method === 'GET' && $parts[0] === 'profissionais' && isset($parts[1]) && isset($parts[2]) && $parts[2] === 'clinicas') {
        $query = "SELECT c.*, pc.id as vinculo_id
                 FROM clinicas c
                 JOIN profissionais_clinicas pc ON pc.clinica_id = c.id
                 WHERE pc.profissional_id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$parts[1]]);
        $clinicas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        jsonResponse($clinicas);
    }

    // Vincular profissional a uma clínica
    if ($method === 'POST' && count($parts) === 4 && 
        $parts[0] === 'profissionais' && 
        $parts[2] === 'clinicas' && 
        $parts[3] === 'vincular') {
        
        $profissionalId = $parts[1];
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['clinica_id'])) {
            jsonResponse(['error' => 'ID da clínica é obrigatório'], 400);
        }

        // Verificar se o profissional existe
        $stmt = $db->prepare("SELECT id FROM profissionais WHERE id = ?");
        $stmt->execute([$profissionalId]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Profissional não encontrado'], 404);
        }

        // Verificar se a clínica existe
        $stmt = $db->prepare("SELECT id FROM clinicas WHERE id = ?");
        $stmt->execute([$data['clinica_id']]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Clínica não encontrada'], 404);
        }

        // Verificar se já existe o vínculo
        $stmt = $db->prepare("SELECT id FROM profissionais_clinicas WHERE profissional_id = ? AND clinica_id = ?");
        $stmt->execute([$profissionalId, $data['clinica_id']]);
        if ($stmt->fetch()) {
            jsonResponse(['error' => 'Profissional já está vinculado a esta clínica'], 400);
        }

        // Criar vínculo
        $stmt = $db->prepare("INSERT INTO profissionais_clinicas (profissional_id, clinica_id) VALUES (?, ?)");
        $stmt->execute([$profissionalId, $data['clinica_id']]);
        
        jsonResponse(['message' => 'Profissional vinculado à clínica com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Listar clínicas vinculadas ao profissional
    if ($method === 'GET' && count($parts) === 3 && 
        $parts[0] === 'profissionais' && 
        $parts[2] === 'clinicas') {
        
        $profissionalId = $parts[1];

        // Verificar se o profissional existe
        $stmt = $db->prepare("SELECT id FROM profissionais WHERE id = ?");
        $stmt->execute([$profissionalId]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Profissional não encontrado'], 404);
        }

        // Buscar clínicas vinculadas
        $stmt = $db->prepare("SELECT c.*, pc.id as vinculo_id
                             FROM clinicas c
                             JOIN profissionais_clinicas pc ON pc.clinica_id = c.id
                             WHERE pc.profissional_id = ?");
        $stmt->execute([$profissionalId]);
        $clinicas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        jsonResponse($clinicas);
    }

    // === ROTAS DE HORÁRIOS DE TRABALHO ===

    // Listar horários de trabalho do profissional em uma clínica
    if ($method === 'GET' && $parts[0] === 'profissionais' && isset($parts[1]) && $parts[2] === 'clinicas' && isset($parts[3]) && $parts[4] === 'horarios') {
        $profissionalId = $parts[1];
        $clinicaId = $parts[3];

        // Verificar se o profissional está vinculado à clínica
        $stmt = $db->prepare("SELECT id FROM profissionais_clinicas WHERE profissional_id = ? AND clinica_id = ?");
        $stmt->execute([$profissionalId, $clinicaId]);
        $vinculo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$vinculo) {
            jsonResponse(['error' => 'Profissional não está vinculado a esta clínica'], 404);
        }

        // Buscar horários de trabalho
        $stmt = $db->prepare("SELECT dia_semana, hora_inicio, hora_fim 
                             FROM horarios_trabalho 
                             WHERE profissional_clinica_id = ?
                             ORDER BY dia_semana, hora_inicio");
        $stmt->execute([$vinculo['id']]);
        $horarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['horarios' => $horarios]);
    }

    // Adicionar horário de trabalho
    if ($method === 'POST' && $parts[0] === 'horarios_trabalho') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['profissional_id']) || !isset($data['clinica_id']) || 
            !isset($data['dia_semana']) || !isset($data['hora_inicio']) || !isset($data['hora_fim'])) {
            jsonResponse(['error' => 'Todos os campos são obrigatórios'], 400);
        }

        if ($data['dia_semana'] < 0 || $data['dia_semana'] > 6) {
            jsonResponse(['error' => 'Dia da semana inválido (0=Domingo, 1=Segunda, ..., 6=Sábado)'], 400);
        }

        // Obter o ID do vínculo profissional-clínica
        $stmt = $db->prepare("SELECT id FROM profissionais_clinicas WHERE profissional_id = ? AND clinica_id = ?");
        $stmt->execute([$data['profissional_id'], $data['clinica_id']]);
        $vinculo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$vinculo) {
            jsonResponse(['error' => 'Profissional não está vinculado a esta clínica'], 404);
        }

        // Verificar se já existe horário sobreposto
        $stmt = $db->prepare("SELECT COUNT(*) FROM horarios_trabalho
                             WHERE profissional_clinica_id = ?
                             AND dia_semana = ?
                             AND ((hora_inicio <= ? AND hora_fim > ?) OR (hora_inicio < ? AND hora_fim >= ?))");
        $stmt->execute([
            $vinculo['id'],
            $data['dia_semana'],
            $data['hora_inicio'],
            $data['hora_inicio'],
            $data['hora_fim'],
            $data['hora_fim']
        ]);
        
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Já existe horário cadastrado que conflita com este período'], 400);
        }

        $stmt = $db->prepare("INSERT INTO horarios_trabalho (profissional_clinica_id, dia_semana, hora_inicio, hora_fim) 
                             VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $vinculo['id'],
            $data['dia_semana'],
            $data['hora_inicio'],
            $data['hora_fim']
        ]);
        
        jsonResponse(['message' => 'Horário de trabalho adicionado com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Remover horário de trabalho
    if ($method === 'DELETE' && $parts[0] === 'profissionais' && isset($parts[1]) && isset($parts[2]) && $parts[2] === 'clinicas' && isset($parts[3]) && isset($parts[4]) && $parts[4] === 'horarios' && isset($parts[5])) {
        // Verificar se existem agendamentos futuros neste horário
        $stmt = $db->prepare("SELECT COUNT(*) FROM agendamentos a
                             JOIN profissionais_clinicas pc ON pc.profissional_id = a.profissional_id AND pc.clinica_id = a.clinica_id
                             JOIN horarios_trabalho ht ON ht.profissional_clinica_id = pc.id
                             WHERE ht.id = ? AND a.data_agendamento >= CURDATE()");
        $stmt->execute([$parts[5]]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Não é possível remover. Existem agendamentos futuros neste horário.'], 400);
        }

        $stmt = $db->prepare("DELETE FROM horarios_trabalho WHERE id = ?");
        if ($stmt->execute([$parts[5]])) {
            jsonResponse(['message' => 'Horário de trabalho removido com sucesso']);
        }
        jsonResponse(['error' => 'Horário de trabalho não encontrado'], 404);
    }

    // === ROTAS DE USUÁRIOS ===

    // Criar usuário
    if ($method === 'POST' && $request === 'usuarios') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['email']) || !isset($data['senha']) || !isset($data['tipo'])) {
            jsonResponse(['error' => 'Todos os campos são obrigatórios'], 400);
        }

        // Verificar se email já existe
        $stmt = $db->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
        $stmt->execute([$data['email']]);
        if ($stmt->fetchColumn() > 0) {
            jsonResponse(['error' => 'Email já cadastrado'], 400);
        }

        // Hash da senha
        $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);

        $stmt = $db->prepare("INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $data['nome'],
            $data['email'],
            $senhaHash,
            $data['tipo']
        ]);

        jsonResponse(['message' => 'Usuário criado com sucesso', 'id' => $db->lastInsertId()], 201);
    }

    // Rota GET /usuarios - Listar usuários (requer admin)
    if ($method === 'GET' && preg_match('/^\/api_clinica\/public\/usuarios\/?$/', $uri)) {
        if (!isset($user['tipo']) || $user['tipo'] !== 'admin') {
            jsonResponse(['error' => 'Acesso negado. Apenas administradores podem listar usuários.'], 403);
        }

        try {
            $db = new Database();
            $stmt = $db->query("SELECT id, nome, email, tipo, created_at, updated_at FROM usuarios");
            $usuarios = $stmt->fetchAll();
            jsonResponse($usuarios);
        } catch (Exception $e) {
            jsonResponse(['error' => 'Erro ao buscar usuários: ' . $e->getMessage()], 500);
        }
    }

    // Rota POST /usuarios - Criar usuário
    if ($method === 'POST' && preg_match('/^\/api_clinica\/public\/usuarios\/?$/', $uri)) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nome']) || !isset($data['email']) || !isset($data['senha']) || !isset($data['tipo'])) {
            jsonResponse(['error' => 'Dados incompletos'], 400);
        }

        if (!in_array($data['tipo'], ['admin', 'profissional'])) {
            jsonResponse(['error' => 'Tipo de usuário inválido'], 400);
        }

        try {
            $db = new Database();
            
            // Verifica se o email já existe
            $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ?");
            $stmt->execute([$data['email']]);
            if ($stmt->fetch()) {
                jsonResponse(['error' => 'Email já cadastrado'], 400);
            }

            $stmt = $db->prepare("
                INSERT INTO usuarios (nome, email, senha, tipo, created_at, updated_at)
                VALUES (?, ?, ?, ?, NOW(), NOW())
            ");

            $senha_hash = password_hash($data['senha'], PASSWORD_DEFAULT);
            
            $stmt->execute([
                $data['nome'],
                $data['email'],
                $senha_hash,
                $data['tipo']
            ]);

            jsonResponse([
                'message' => 'Usuário criado com sucesso',
                'id' => $db->lastInsertId()
            ]);
        } catch (Exception $e) {
            jsonResponse(['error' => 'Erro ao criar usuário: ' . $e->getMessage()], 500);
        }
    }

    // Rota PUT /usuarios/{id} - Atualizar usuário (requer admin)
    if ($method === 'PUT' && preg_match('/^\/api_clinica\/public\/usuarios\/(\d+)\/?$/', $uri, $matches)) {
        if (!isset($user['tipo']) || $user['tipo'] !== 'admin') {
            jsonResponse(['error' => 'Acesso negado. Apenas administradores podem atualizar usuários.'], 403);
        }

        $id = $matches[1];
        $data = json_decode(file_get_contents('php://input'), true);

        try {
            $db = new Database();
            $updates = [];
            $params = [];

            if (isset($data['nome'])) {
                $updates[] = "nome = ?";
                $params[] = $data['nome'];
            }

            if (isset($data['email'])) {
                // Verifica se o email já existe para outro usuário
                $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
                $stmt->execute([$data['email'], $id]);
                if ($stmt->fetch()) {
                    jsonResponse(['error' => 'Email já cadastrado para outro usuário'], 400);
                }

                $updates[] = "email = ?";
                $params[] = $data['email'];
            }

            if (isset($data['senha'])) {
                $updates[] = "senha = ?";
                $params[] = password_hash($data['senha'], PASSWORD_DEFAULT);
            }

            if (isset($data['tipo'])) {
                if (!in_array($data['tipo'], ['admin', 'profissional'])) {
                    jsonResponse(['error' => 'Tipo de usuário inválido'], 400);
                }
                $updates[] = "tipo = ?";
                $params[] = $data['tipo'];
            }

            if (empty($updates)) {
                jsonResponse(['error' => 'Nenhum dado para atualizar'], 400);
            }

            $updates[] = "updated_at = NOW()";
            $params[] = $id;

            $sql = "UPDATE usuarios SET " . implode(", ", $updates) . " WHERE id = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);

            if ($stmt->rowCount() === 0) {
                jsonResponse(['error' => 'Usuário não encontrado'], 404);
            }

            jsonResponse(['message' => 'Usuário atualizado com sucesso']);
        } catch (Exception $e) {
            jsonResponse(['error' => 'Erro ao atualizar usuário: ' . $e->getMessage()], 500);
        }
    }

    // Rota DELETE /usuarios/{id} - Deletar usuário (requer admin)
    if ($method === 'DELETE' && preg_match('/^\/api_clinica\/public\/usuarios\/(\d+)\/?$/', $uri, $matches)) {
        if (!isset($user['tipo']) || $user['tipo'] !== 'admin') {
            jsonResponse(['error' => 'Acesso negado. Apenas administradores podem deletar usuários.'], 403);
        }

        $id = $matches[1];

        try {
            $db = new Database();

            // Verifica se o usuário existe
            $stmt = $db->prepare("SELECT tipo FROM usuarios WHERE id = ?");
            $stmt->execute([$id]);
            $usuario = $stmt->fetch();

            if (!$usuario) {
                jsonResponse(['error' => 'Usuário não encontrado'], 404);
            }

            // Não permite deletar o último admin
            if ($usuario['tipo'] === 'admin') {
                $stmt = $db->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'admin'");
                $result = $stmt->fetch();
                if ($result['total'] <= 1) {
                    jsonResponse(['error' => 'Não é possível deletar o último administrador'], 400);
                }
            }

            $stmt = $db->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->execute([$id]);

            jsonResponse(['message' => 'Usuário deletado com sucesso']);
        } catch (Exception $e) {
            jsonResponse(['error' => 'Erro ao deletar usuário: ' . $e->getMessage()], 500);
        }
    }

    // Cancelar agendamento
    if ($method === 'POST' && count($parts) === 3 && 
        $parts[0] === 'agendamentos' && 
        $parts[2] === 'cancelar') {
        
        $agendamentoId = $parts[1];

        // Verificar se o agendamento existe e pode ser cancelado
        $stmt = $db->prepare("SELECT status FROM agendamentos WHERE id = ?");
        $stmt->execute([$agendamentoId]);
        $agendamento = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$agendamento) {
            jsonResponse(['error' => 'Agendamento não encontrado'], 404);
        }

        if ($agendamento['status'] === 'cancelado') {
            jsonResponse(['error' => 'Agendamento já está cancelado'], 400);
        }

        if ($agendamento['status'] === 'realizado') {
            jsonResponse(['error' => 'Não é possível cancelar um agendamento já realizado'], 400);
        }

        // Cancelar o agendamento
        $stmt = $db->prepare("UPDATE agendamentos SET status = 'cancelado', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$agendamentoId]);
        
        jsonResponse(['message' => 'Agendamento cancelado com sucesso']);
    }

    // Atualizar status do agendamento
    if ($method === 'PUT' && count($parts) === 3 && 
        $parts[0] === 'agendamentos' && 
        $parts[2] === 'status') {
        
        $agendamentoId = $parts[1];
        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['status'])) {
            jsonResponse(['error' => 'Status é obrigatório'], 400);
        }

        $statusPermitidos = ['agendado', 'confirmado', 'realizado', 'cancelado'];
        if (!in_array($data['status'], $statusPermitidos)) {
            jsonResponse(['error' => 'Status inválido. Use: ' . implode(', ', $statusPermitidos)], 400);
        }

        // Verificar se o agendamento existe
        $stmt = $db->prepare("SELECT status FROM agendamentos WHERE id = ?");
        $stmt->execute([$agendamentoId]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Agendamento não encontrado'], 404);
        }

        // Atualizar status
        $stmt = $db->prepare("UPDATE agendamentos SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$data['status'], $agendamentoId]);
        
        jsonResponse(['message' => 'Status atualizado com sucesso']);
    }

    // Buscar profissionais por especialidade
    if ($method === 'GET' && count($parts) === 2 && 
        $parts[0] === 'especialidades' && 
        $parts[1] === 'profissionais') {
        
        $especialidadeId = isset($_GET['especialidade_id']) ? $_GET['especialidade_id'] : null;
        
        error_log("Buscando profissionais para especialidade: " . $especialidadeId);
        
        if (!$especialidadeId) {
            // Se não foi informada especialidade, retorna todos os profissionais
            $sql = "SELECT p.*, u.nome, u.email, e.nome as especialidade_nome 
                    FROM profissionais p
                    JOIN usuarios u ON p.usuario_id = u.id
                    JOIN especialidades e ON e.id = p.especialidade_id
                    ORDER BY u.nome";
            $stmt = $db->prepare($sql);
            $stmt->execute();
            $profissionais = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // Verificar se a especialidade existe
            $sql = "SELECT id FROM especialidades WHERE id = ?";
            error_log("SQL verificação especialidade: " . $sql);
            error_log("Params verificação especialidade: " . json_encode([$especialidadeId]));
            
            $stmt = $db->prepare($sql);
            $stmt->execute([$especialidadeId]);
            $especialidade = $stmt->fetch();
            error_log("Especialidade encontrada: " . json_encode($especialidade));
            
            if (!$especialidade) {
                error_log("Especialidade não encontrada no banco de dados");
                jsonResponse(['error' => 'Especialidade não encontrada'], 404);
                return;
            }

            // Buscar profissionais da especialidade
            $sql = "SELECT p.*, u.nome, u.email, e.nome as especialidade_nome 
                    FROM profissionais p
                    JOIN usuarios u ON p.usuario_id = u.id
                    JOIN especialidades e ON e.id = p.especialidade_id
                    WHERE p.especialidade_id = ?
                    ORDER BY u.nome";
            error_log("SQL busca profissionais: " . $sql);
            error_log("Params busca profissionais: " . json_encode([$especialidadeId]));
            
            $stmt = $db->prepare($sql);
            $stmt->execute([$especialidadeId]);
            $profissionais = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("Profissionais encontrados: " . json_encode($profissionais));
        }
        
        jsonResponse(['profissionais' => $profissionais]);
    }

    // Buscar procedimentos por especialidade
    if ($method === 'GET' && count($parts) === 3 && 
        $parts[0] === 'especialidades' && 
        $parts[1] === 'procedimentos') {
        
        $especialidadeId = $parts[2];
        
        // Verificar se a especialidade existe
        $stmt = $db->prepare("SELECT id FROM especialidades WHERE id = ?");
        $stmt->execute([$especialidadeId]);
        if (!$stmt->fetch()) {
            jsonResponse(['error' => 'Especialidade não encontrada'], 404);
        }

        // Buscar procedimentos da especialidade
        $stmt = $db->prepare("SELECT p.*, e.nome as especialidade
                             FROM procedimentos p
                             JOIN especialidades e ON e.id = p.especialidade_id
                             WHERE p.especialidade_id = ?");
        $stmt->execute([$especialidadeId]);
        $procedimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        jsonResponse($procedimentos);
    }

    // Listar horários de trabalho de um profissional em uma clínica
    if ($method === 'GET' && $parts[0] === 'profissionais' && isset($parts[1]) && $parts[2] === 'clinicas' && isset($parts[3]) && $parts[4] === 'horarios') {
        $profissionalId = $parts[1];
        $clinicaId = $parts[3];

        // Verificar se o profissional está vinculado à clínica
        $stmt = $db->prepare("SELECT id FROM profissionais_clinicas WHERE profissional_id = ? AND clinica_id = ?");
        $stmt->execute([$profissionalId, $clinicaId]);
        $vinculo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$vinculo) {
            jsonResponse(['error' => 'Profissional não está vinculado a esta clínica'], 404);
        }

        // Buscar horários de trabalho
        $stmt = $db->prepare("SELECT dia_semana, hora_inicio, hora_fim 
                             FROM horarios_trabalho 
                             WHERE profissional_clinica_id = ?
                             ORDER BY dia_semana, hora_inicio");
        $stmt->execute([$vinculo['id']]);
        $horarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['horarios' => $horarios]);
    }

    // Listar agendamentos de um profissional em uma data
    if ($method === 'GET' && count($parts) === 3 && 
        $parts[0] === 'profissionais' && 
        $parts[2] === 'agendamentos') {
        
        $profissionalId = $parts[1];
        $data = isset($_GET['data']) ? $_GET['data'] : date('Y-m-d');

        // Validar a data
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
            jsonResponse(['error' => 'Data inválida. Use o formato YYYY-MM-DD'], 400);
        }

        // Buscar agendamentos
        $stmt = $db->prepare("SELECT a.*, c.nome as clinica_nome, p.nome as procedimento_nome
                             FROM agendamentos a
                             JOIN clinicas c ON a.clinica_id = c.id
                             JOIN procedimentos p ON a.procedimento_id = p.id
                             WHERE a.profissional_id = ? 
                             AND a.data_agendamento = ?
                             ORDER BY a.hora_inicio");
        $stmt->execute([$profissionalId, $data]);
        $agendamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['agendamentos' => $agendamentos]);
    }

    // Rota GET /profissionais/{id}/horarios-disponiveis - Listar horários disponíveis
    if ($method === 'GET' && preg_match('/^\/api_clinica\/public\/profissionais\/(\d+)\/horarios-disponiveis\/?$/', $uri, $matches)) {
        $profissional_id = $matches[1];
        $data = isset($_GET['data']) ? $_GET['data'] : date('Y-m-d');

        try {
            $db = new Database();

            // Verifica se o profissional existe
            $stmt = $db->prepare("
                SELECT p.*, u.nome, u.email, e.nome as especialidade
                FROM profissionais p
                JOIN usuarios u ON p.usuario_id = u.id
                JOIN especialidades e ON e.id = p.especialidade_id
                WHERE p.id = ?
            ");
            $stmt->execute([$profissional_id]);
            $profissional = $stmt->fetch();

            if (!$profissional) {
                jsonResponse(['error' => 'Profissional não encontrado'], 404);
            }

            // Busca os horários já agendados para o profissional na data
            $stmt = $db->prepare("
                SELECT hora_inicio, hora_fim
                FROM agendamentos
                WHERE profissional_id = ? 
                AND data_agendamento = ?
                AND status != 'cancelado'
            ");
            $stmt->execute([$profissional_id, $data]);
            $agendamentos = $stmt->fetchAll();

            // Define o horário de trabalho padrão (8h às 18h)
            $inicio_trabalho = '08:00:00';
            $fim_trabalho = '18:00:00';
            $duracao_consulta = 30; // minutos

            // Gera todos os horários possíveis
            $horarios_disponiveis = [];
            $hora_atual = strtotime($inicio_trabalho);
            $hora_fim = strtotime($fim_trabalho);

            while ($hora_atual < $hora_fim) {
                $hora_inicio = date('H:i:s', $hora_atual);
                $hora_fim_slot = date('H:i:s', $hora_atual + ($duracao_consulta * 60));

                // Verifica se o horário está disponível
                $disponivel = true;
                foreach ($agendamentos as $agendamento) {
                    if (
                        ($hora_inicio >= $agendamento['hora_inicio'] && $hora_inicio < $agendamento['hora_fim']) ||
                        ($hora_fim_slot > $agendamento['hora_inicio'] && $hora_fim_slot <= $agendamento['hora_fim']) ||
                        ($hora_inicio <= $agendamento['hora_inicio'] && $hora_fim_slot >= $agendamento['hora_fim'])
                    ) {
                        $disponivel = false;
                        break;
                    }
                }

                if ($disponivel) {
                    $horarios_disponiveis[] = [
                        'hora_inicio' => $hora_inicio,
                        'hora_fim' => $hora_fim_slot
                    ];
                }

                $hora_atual += ($duracao_consulta * 60);
            }

            jsonResponse([
                'profissional' => [
                    'id' => $profissional['id'],
                    'nome' => $profissional['nome'],
                    'especialidade' => $profissional['especialidade']
                ],
                'data' => $data,
                'horarios_disponiveis' => $horarios_disponiveis
            ]);
        } catch (Exception $e) {
            jsonResponse(['error' => 'Erro ao buscar horários disponíveis: ' . $e->getMessage()], 500);
        }
    }

    // Rota não encontrada
    jsonResponse(['error' => 'Rota não encontrada'], 404);

} catch (Exception $e) {
    jsonResponse(['error' => 'Erro interno do servidor: ' . $e->getMessage()], 500);
}
