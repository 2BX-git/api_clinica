ALTER TABLE profissionais_clinicas ADD COLUMN dias_atendimento VARCHAR(20) NOT NULL;
