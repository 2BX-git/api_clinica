<?php
$config = parse_ini_file(__DIR__ . '/../.env');

try {
    $pdo = new PDO(
        "mysql:host={$config['DB_HOST']};port={$config['DB_PORT']};dbname={$config['DB_NAME']}",
        $config['DB_USER'],
        $config['DB_PASS'],
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
    );
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Criar tabelas uma por uma
    $tables = [
        // Tabelas principais primeiro
        "CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            senha VARCHAR(255) NOT NULL,
            tipo ENUM('admin', 'profissional') NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS especialidades (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            descricao TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS clinicas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            endereco TEXT NOT NULL,
            telefone VARCHAR(20),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS profissionais (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NOT NULL,
            especialidade_id INT NOT NULL,
            registro_profissional VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
            FOREIGN KEY (especialidade_id) REFERENCES especialidades(id)
        )",
        
        "CREATE TABLE IF NOT EXISTS profissionais_clinicas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            profissional_id INT NOT NULL,
            clinica_id INT NOT NULL,
            dias_atendimento VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (profissional_id) REFERENCES profissionais(id),
            FOREIGN KEY (clinica_id) REFERENCES clinicas(id),
            UNIQUE KEY unique_profissional_clinica (profissional_id, clinica_id)
        )",
        
        "CREATE TABLE IF NOT EXISTS horarios_trabalho (
            id INT AUTO_INCREMENT PRIMARY KEY,
            profissional_clinica_id INT NOT NULL,
            dia_semana TINYINT NOT NULL COMMENT '0=Domingo, 1=Segunda, ..., 6=Sábado',
            hora_inicio TIME NOT NULL,
            hora_fim TIME NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (profissional_clinica_id) REFERENCES profissionais_clinicas(id),
            CONSTRAINT hora_valida CHECK (hora_inicio < hora_fim)
        )",
        
        "CREATE TABLE IF NOT EXISTS procedimentos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            descricao TEXT,
            duracao INT NOT NULL COMMENT 'Duração em minutos',
            especialidade_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (especialidade_id) REFERENCES especialidades(id)
        )",
        
        "CREATE TABLE IF NOT EXISTS agendamentos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            profissional_id INT NOT NULL,
            clinica_id INT NOT NULL,
            procedimento_id INT NOT NULL,
            paciente_nome VARCHAR(100) NOT NULL,
            paciente_telefone VARCHAR(20),
            data_agendamento DATE NOT NULL,
            hora_inicio TIME NOT NULL,
            hora_fim TIME NOT NULL,
            status ENUM('agendado', 'confirmado', 'cancelado', 'realizado') NOT NULL DEFAULT 'agendado',
            observacoes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (profissional_id) REFERENCES profissionais(id),
            FOREIGN KEY (clinica_id) REFERENCES clinicas(id),
            FOREIGN KEY (procedimento_id) REFERENCES procedimentos(id)
        )",
        
        "CREATE TABLE IF NOT EXISTS logs (
            id INT PRIMARY KEY AUTO_INCREMENT,
            usuario_id INT,
            acao VARCHAR(50) NOT NULL,
            tabela VARCHAR(50) NOT NULL,
            registro_id INT NOT NULL,
            dados_anteriores JSON,
            dados_novos JSON,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )"
    ];
    
    foreach ($tables as $sql) {
        try {
            $pdo->exec($sql);
            echo "Tabela criada com sucesso!\n";
        } catch (PDOException $e) {
            echo "Erro ao criar tabela: " . $e->getMessage() . "\n";
        }
    }
    
    echo "Processo concluído!\n";
} catch (PDOException $e) {
    echo "Erro de conexão: " . $e->getMessage() . "\n";
}
?>
