<?php
$config = parse_ini_file(__DIR__ . '/../.env');

try {
    $pdo = new PDO(
        "mysql:host={$config['DB_HOST']};port={$config['DB_PORT']};dbname={$config['DB_NAME']}",
        $config['DB_USER'],
        $config['DB_PASS'],
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
    );
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Remover tabelas que dependem de profissionais_clinicas
    $pdo->exec("DROP TABLE IF EXISTS horarios_trabalho");
    
    // Recriar a tabela profissionais_clinicas com a estrutura correta
    $pdo->exec("DROP TABLE IF EXISTS profissionais_clinicas");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS profissionais_clinicas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        profissional_id INT NOT NULL,
        clinica_id INT NOT NULL,
        dias_atendimento VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (profissional_id) REFERENCES profissionais(id),
        FOREIGN KEY (clinica_id) REFERENCES clinicas(id),
        UNIQUE KEY unique_profissional_clinica (profissional_id, clinica_id)
    )");
    
    // Criar a tabela horarios_trabalho
    $pdo->exec("CREATE TABLE IF NOT EXISTS horarios_trabalho (
        id INT AUTO_INCREMENT PRIMARY KEY,
        profissional_clinica_id INT NOT NULL,
        dia_semana TINYINT NOT NULL COMMENT '0=Domingo, 1=Segunda, ..., 6=Sábado',
        hora_inicio TIME NOT NULL,
        hora_fim TIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (profissional_clinica_id) REFERENCES profissionais_clinicas(id),
        CONSTRAINT hora_valida CHECK (hora_inicio < hora_fim)
    )");
    
    echo "Tabelas corrigidas com sucesso!\n";
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage() . "\n";
}
?>
