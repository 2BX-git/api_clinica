<?php

namespace Src\Middleware;

use Src\Auth\JWT;

class AuthMiddleware {
    public static function authenticate($request) {
        $headers = getallheaders();
        $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : null;

        if (!$token) {
            http_response_code(401);
            echo json_encode(['error' => 'Token não fornecido']);
            exit;
        }

        $payload = JWT::validateToken($token);
        if (!$payload) {
            http_response_code(401);
            echo json_encode(['error' => 'Token inválido ou expirado']);
            exit;
        }

        // Adiciona os dados do usuário ao request
        $request->user = $payload;
        return true;
    }

    public static function requireAdmin($request) {
        if (!isset($request->user['tipo']) || $request->user['tipo'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Acesso negado. Apenas administradores podem acessar este recurso.']);
            exit;
        }
        return true;
    }

    public static function requireProfissional($request) {
        if (!isset($request->user['tipo']) || 
            ($request->user['tipo'] !== 'profissional' && $request->user['tipo'] !== 'admin')) {
            http_response_code(403);
            echo json_encode(['error' => 'Acesso negado. Apenas profissionais podem acessar este recurso.']);
            exit;
        }
        return true;
    }
}
