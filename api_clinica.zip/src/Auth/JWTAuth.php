<?php

namespace Src\Auth;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JWTAuth {
    private static $key = 'sua_chave_secreta_muito_segura_2024';
    private static $algorithm = 'HS256';

    public static function generateToken($user) {
        $issuedAt = time();
        $expire = $issuedAt + 3600; // Token expira em 1 hora

        $payload = [
            'iat' => $issuedAt,
            'exp' => $expire,
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'tipo' => $user['tipo']
            ]
        ];

        return JWT::encode($payload, self::$key, self::$algorithm);
    }

    public static function validateToken($token) {
        try {
            if (empty($token)) {
                return false;
            }

            $decoded = JWT::decode($token, new Key(self::$key, self::$algorithm));
            return $decoded;
        } catch (\Exception $e) {
            return false;
        }
    }

    public static function getUser($token) {
        $decoded = self::validateToken($token);
        return $decoded ? $decoded->user : null;
    }
}
