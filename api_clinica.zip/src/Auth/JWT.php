<?php

namespace Src\Auth;

class JWT {
    private static $key = 'chave_super_secreta_2024_api_clinica';
    private static $algorithm = 'sha256';

    public static function generateToken($data, $expireInHours = 24) {
        $header = [
            'alg' => self::$algorithm,
            'typ' => 'JWT'
        ];

        $issuedAt = time();
        $expire = $issuedAt + ($expireInHours * 3600);

        $payload = array_merge($data, [
            'iat' => $issuedAt,
            'exp' => $expire
        ]);

        $base64Header = self::base64UrlEncode(json_encode($header));
        $base64Payload = self::base64UrlEncode(json_encode($payload));

        $signature = hash_hmac(
            self::$algorithm,
            $base64Header . '.' . $base64Payload,
            self::$key,
            true
        );

        $base64Signature = self::base64UrlEncode($signature);

        return $base64Header . '.' . $base64Payload . '.' . $base64Signature;
    }

    public static function validateToken($token) {
        try {
            $parts = explode('.', $token);

            if (count($parts) !== 3) {
                return false;
            }

            list($base64Header, $base64Payload, $base64Signature) = $parts;

            $signature = self::base64UrlDecode($base64Signature);
            $expectedSignature = hash_hmac(
                self::$algorithm,
                $base64Header . '.' . $base64Payload,
                self::$key,
                true
            );

            if (!hash_equals($signature, $expectedSignature)) {
                return false;
            }

            $payload = json_decode(self::base64UrlDecode($base64Payload), true);

            if (!$payload) {
                return false;
            }

            if (isset($payload['exp']) && $payload['exp'] < time()) {
                return false;
            }

            return $payload;
        } catch (\Exception $e) {
            return false;
        }
    }

    private static function base64UrlEncode($data) {
        $base64 = base64_encode($data);
        $base64Url = strtr($base64, '+/', '-_');
        return rtrim($base64Url, '=');
    }

    private static function base64UrlDecode($data) {
        $base64 = strtr($data, '-_', '+/');
        $padded = str_pad($base64, strlen($base64) % 4, '=', STR_PAD_RIGHT);
        return base64_decode($padded);
    }
}
