<?php

namespace Src;

use PDO;
use PDOException;

class Database extends PDO
{
    private $host = "server.2bx.com.br";
    private $port = "3310";
    private $database_name = "agenda";
    private $username = "mysql";
    private $password = "5b1f0d62e5f0b4b87cf7";

    public function __construct()
    {
        try {
            parent::__construct(
                "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->database_name,
                $this->username,
                $this->password,
                array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
            );
            $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
    }
}
